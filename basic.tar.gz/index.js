'use strict';

const AssetTransfer = require('./lib/assetTransfer');

module.exports.AssetTransfer = AssetTransfer;
module.exports.contracts = [AssetTransfer];
